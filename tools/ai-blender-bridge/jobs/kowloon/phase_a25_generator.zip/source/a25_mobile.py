"""Build the current allowlisted Android bridge job. The local city stays metric."""
import json, hashlib
from collections import defaultdict
from phase_a25 import generate, Mesh, ROOT, triangles, polygons, write, Polygon, unary_union
def coord(v):
    n=round(float(v),2)
    return int(n) if n==int(n) else n
def mobile_parts(parts):
    out=[];road_stats=[]
    for m in parts:
        if m.category=='street':
            tops=[Polygon([m.verts[j][:2] for j in f]) for f in m.faces if all(m.verts[j][2]==0 for j in f)]
            surface=unary_union(tops);simple=surface.simplify(.09,preserve_topology=True)
            assert abs(simple.area-surface.area)<max(1,.012*surface.area)
            road=Mesh(m.name,m.category,m.source)
            for poly in polygons(simple):
                for tri in triangles(poly):road.face([(*p,0) for p in list(tri.exterior.coords)[:3]])
            road_stats.append(dict(name=m.name,original_m2=surface.area,mobile_m2=simple.area))
            m=road
        out.append(m)
    return out,road_stats
def combine(group):
    merged=Mesh('KWC_'+group[0].name,group[0].category,'')
    for m in group:
        for f in m.faces:merged.face([[coord(x) for x in m.verts[i]] for i in f])
    return dict(op='mesh',name=merged.name,vertices=[[coord(x) for x in v] for v in merged.verts],faces=merged.faces)
if __name__=='__main__':
    parts,reg,ledger,offset=generate()
    parts,roads=mobile_parts(parts)
    groups=defaultdict(list)
    for m in parts:groups[m.category].append(m)
    steps=[dict(op='save',label='before-kowloon'),dict(op='reset')]
    table={}
    for cat,objects in groups.items():
        for i in range(0,len(objects),2):
            group=objects[i:i+2];step=combine(group)
            table[step['name']]=[m.name for m in group];steps.append(step)
    steps.extend([
        dict(op='camera',name='九龍城_A25全景',location=[-38,-325,207],target=[0,0,19],lens=48),
        dict(op='light',name='九龍城_A25昼光',type='SUN',location=[-150,-200,290],target=[0,0,0],energy=3.5),
        dict(op='world',color=[.8,.8,.8],strength=.55),dict(op='render_settings',width=720,height=480),
        dict(op='save',label='completed-kowloon'),dict(op='render',width=640,height=426,label='a25-overview'),dict(op='status')])
    job=dict(id='kowloon-a25-registered-city-20261128',title='Kowloon A25 / 234 survey plots and registered elevations',project='kowloon',source_origin_OBJ=[offset[0],0,-offset[1]],steps=steps)
    assert len(steps)<=240
    weight=len(json.dumps(job,ensure_ascii=False).encode())
    print('Wire size',weight,'steps',len(steps),'meshes',len(table),flush=True)
    assert weight<=512000 and len(table)>=100
    path=ROOT/'automation/phase_a25_android.json'
    path.write_text(json.dumps(job,ensure_ascii=False,separators=(',',':'))+'\n')
    write('phase_a/a25_mobile_index.json',dict(groups=table,streets=roads,units='metres; XY centred as in A24, Z up',rounding_m=.01,
          changes='Road reference surface simplified 0.09m. Other groups share A25 source geometry, rounded to 0.01m for wire transfer.',
          wire_bytes=weight,sha256=hashlib.sha256(path.read_bytes()).hexdigest()))
