"""Reconcile only A25-owned meshes into a copy of the existing Blender project."""
import bpy, json, os, shutil, hashlib, sys
from pathlib import Path
from mathutils import Vector
R=Path(__file__).resolve().parents[1]
target=R/'Kowloon_v25_working.blend'
source=target if target.exists() else R/'Kowloon_v19_working.blend'
backup=R/'Phase_A_before_update.blend'
shutil.copyfile(source,backup.with_suffix('.pending'))
os.replace(backup.with_suffix('.pending'),backup)
bpy.ops.wm.open_mainfile(filepath=str(source))
scene=bpy.data.scenes.get('A25 | 九龍城砦・全域') or bpy.data.scenes.new('A25 | 九龍城砦・全域')
scene.use_fake_user=True
bpy.context.window.scene=scene
scene.unit_settings.system='METRIC'
reg=json.loads((R/'phase_a/a25_register.json').read_text())
meta={p['name']:p for p in reg['parts']}
plots={p['id']:p for p in reg['plots']}
records={p['id']:p for p in json.loads((R/'phase_a/city.json').read_text())['records']}
owned={o['part_id']:o for o in scene.objects if o.get('generator')=='phase_a25'}
def collection(name):
    c=scene.collection.children.get(name)
    if not c:
        c=bpy.data.collections.new(name);scene.collection.children.link(c)
    return c
groups={'plot':'01 | 区画外形・高さ仮定', 'aerial roof division':'02 | 空撮屋根の割当候補','A24 projection':'03 | 仮の張り出し',
        'central low rise':'04 | 中央低層部','north survey':'05 | 北街区の断面と通路','west study':'06 | 西側の写真解析','street':'07 | 街路'}
pts=[];seen=set()
def part(name,verts,faces):
    if not name:return
    data=meta[name];seen.add(name)
    digest=hashlib.sha256(repr((verts,faces,data)).encode()).hexdigest()
    grouping=groups[data['category']]
    if data['category']=='plot':
        p=plots[name[2:]]
        grouping=('01a | 階数採録・階高仮定' if p['storeys'] else
                  '01b | 南西立面から高さを推定' if p['height_status'].startswith('elevation') else
                  '01c | 高さ未詳・近隣値で仮表示')
    obj=owned.get(name)
    if not obj or obj.get('geometry_sha')!=digest:
        mesh=bpy.data.meshes.new(name);mesh.from_pydata(verts,[],faces);mesh.update()
        if mesh.validate(verbose=False):raise ValueError('Blender repaired '+name)
        if obj:
            old=obj.data;obj.data=mesh
            if not old.users:bpy.data.meshes.remove(old)
        else:obj=bpy.data.objects.new(name,mesh)
    dest=collection(grouping)
    if dest not in obj.users_collection:dest.objects.link(obj)
    for c in list(obj.users_collection):
        if c!=dest and c in scene.collection.children_recursive:c.objects.unlink(obj)
        obj['geometry_sha']=digest
    obj['generator']='phase_a25';obj['part_id']=name;obj['source']=data['source']
    if data['category']=='plot':
        plot=plots[name[2:]]
        for k in ('height_status','height_A24','height_A25','target_epoch'):obj[k]=plot[k]
        if plot['storeys']:obj['source_storeys']=plot['storeys']
        obj['elevation_candidate_ids']=' '.join(h['id'] for h in reg['observations'] if h.get('parcel')==name[2:] and h['status']=='cut_candidate')
    pts.extend(Vector(p) for p in verts)
offset=0;verts=[];faces=[];name=None
for line in (R/'model/39_whole_city_registered_exteriors.obj').read_text().splitlines():
    if line.startswith('o '):
        part(name,verts,faces);offset+=len(verts);verts=[];faces=[];name=line[2:]
    elif line.startswith('v '):
        x,y,z=map(float,line.split()[1:]);verts.append((x,-z,y))
    elif line.startswith('f '):faces.append([int(i)-1-offset for i in line.split()[1:]])
part(name,verts,faces)
assert set(meta)==seen
for key in owned.keys()-seen:
    bpy.data.objects.remove(owned[key],do_unlink=True)
scene['survey']='D04 Fig.2–4 / Expedition south and west elevation. See phase_a/a25_register.json'
scene['horizontal_frame']='D04 Fig2, 50m scale bar; local datum 0. Heights provisional.'
scene.render.engine='BLENDER_WORKBENCH'
shade=scene.display.shading
shade.light='STUDIO';shade.color_type='SINGLE';shade.single_color=(.76,.76,.76)
shade.background_type='WORLD'
world=scene.world or bpy.data.worlds.new('A25 paper');world.color=(.83,.83,.83);scene.world=world
shade.show_shadows=True;shade.show_cavity=True;shade.cavity_type='WORLD'
shade.cavity_ridge_factor=1.1;shade.cavity_valley_factor=1.15
scene.display.matcap_ssao_distance=2.5
scene.view_settings.exposure=.6
scene.render.resolution_x=1320;scene.render.resolution_y=852;scene.render.resolution_percentage=100
scene.render.image_settings.file_format='PNG';scene.view_settings.view_transform='Standard'
rig=collection('08 | 全景・南面カメラ')
def camera(name,direction,selection):
    ob=rig.objects.get(name)
    if not ob:
        ob=bpy.data.objects.new(name,bpy.data.cameras.new(name));rig.objects.link(ob)
    lo=Vector([min(v[i] for v in selection) for i in range(3)])
    hi=Vector([max(v[i] for v in selection) for i in range(3)]);mid=(lo+hi)/2
    view=Vector(direction).normalized();ob.location=mid+view*400
    ob.rotation_euler=(-view).to_track_quat('-Z','Y').to_euler()
    ob.data.type='ORTHO';ob.data.clip_end=2000
    rot=ob.rotation_euler.to_matrix();x=rot@Vector((1,0,0));y=rot@Vector((0,1,0))
    xx=[p.dot(x) for p in selection];yy=[p.dot(y) for p in selection]
    ob.location+=x*((min(xx)+max(xx))/2-mid.dot(x))+y*((min(yy)+max(yy))/2-mid.dot(y))
    ob.data.ortho_scale=max(max(xx)-min(xx),(max(yy)-min(yy))*scene.render.resolution_x/scene.render.resolution_y)*1.09
    return ob
whole=camera('Kowloon | 全景',(-.18,-1.6,.95),pts)
affected=set(h['parcel'] for h in reg['observations'] if h['status']=='cut_candidate' and h['view']=='south')
front=[v.co.copy() for o in scene.objects if o.get('part_id','')[2:] in affected for v in o.data.vertices]
detail=camera('Kowloon | 南面',(.56,-.83,.21),front)
scene.camera=whole
for screen in bpy.data.screens:
    for area in screen.areas:
        if area.type=='VIEW_3D':
            space=area.spaces.active
            if space.region_3d:
                space.region_3d.view_perspective='CAMERA'
                space.region_3d.view_camera_zoom=5
                space.clip_end=2000
                space.overlay.show_overlays=False
                space.shading.type='SOLID';space.shading.color_type='SINGLE'
                space.shading.single_color=(.76,.76,.76);space.shading.show_shadows=True;space.shading.show_cavity=True
bpy.context.preferences.filepaths.save_version=0
temp=target.with_name('A25_build_pending.blend')
bpy.ops.wm.save_as_mainfile(filepath=str(temp),compress=True)
os.replace(temp,target)
for ob,label in [(whole,'whole'),(detail,'south')]:
    scene.camera=ob;scene.render.filepath=str(R/f'preview/a25_{label}.png')
    bpy.ops.render.render(write_still=True,scene=scene.name)
print('A25_NATIVE',len(seen),len(front))
