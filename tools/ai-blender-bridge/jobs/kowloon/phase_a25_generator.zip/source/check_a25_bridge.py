"""Exercise the real Termux relay and Blender code against a loopback temp server.

Run with blender -b --python-exit-code 1 --python check_a25_bridge.py -- BRIDGE_DIR TAG.
"""
import bpy, os, json, sys, threading, tempfile, importlib.util, hashlib
from pathlib import Path
from unittest.mock import patch
from mathutils import Vector
R=Path(__file__).resolve().parents[1]
repo,tag=sys.argv[sys.argv.index('--')+1:];repo=Path(repo).resolve()
agent=repo/'blender_agent.py'
ns={'BRIDGE_TOKEN':'test-only'}
exec(compile(agent.read_text(),str(agent),'exec'),ns)
bpy.app.timers.unregister(ns['ai_bridge_tick'])
with tempfile.TemporaryDirectory() as temp:
    with patch('pathlib.Path.home',return_value=Path(temp)):
        spec=importlib.util.spec_from_file_location('relay',repo/'bridge_server.py')
        relay=importlib.util.module_from_spec(spec);spec.loader.exec_module(relay)
    http=relay.ThreadingHTTPServer(('127.0.0.1',0),relay.Handler)
    threading.Thread(target=http.serve_forever,daemon=True).start()
    ns['BASE_URL']='http://127.0.0.1:'+str(http.server_address[1]);ns['BRIDGE_TOKEN']=relay.TOKEN
    original=bpy.context.scene
    protected=bpy.data.objects.new('ordinary_scene_marker',None);original.collection.objects.link(protected)
    ns['create_box'](dict(name='prior_studio_marker',location=[0,0,0],size=[1,1,1]))
    job=json.loads((R/'automation/phase_a25_android.json').read_text())
    assert relay.verify_job(job)==job['id']
    assert ns['request']('/submit',job)['queued']
    received=ns['request']('/next')['job'];assert received==job
    result=ns['run_one'](received);assert result['ok'],result
    assert ns['request']('/result',result)['ok']
    assert not ns['request']('/submit',received)['queued']
    old=next(relay.OUTPUT_DIR.glob('*before-kowloon.blend'))
    with bpy.data.libraries.load(str(old)) as (source,dst):assert 'prior_studio_marker' in source.objects
    assert 'ordinary_scene_marker' in original.objects
    scene=ns['studio']();steps=[s for s in received['steps'] if s['op']=='mesh']
    def inspect_meshes():
        objs={o.name:o for o in scene.objects if o.type=='MESH'};assert len(steps)==len(objs)
        maximum=0
        for s in steps:
            m=objs[s['name']].data
            assert not m.materials and len(m.vertices)==len(s['vertices'])
            assert [list(p.vertices) for p in m.polygons]==s['faces']
            maximum=max(maximum,max((v.co-Vector(p)).length for v,p in zip(m.vertices,s['vertices'])))
        assert maximum<.00001
        return maximum
    e=inspect_meshes()
    cp=relay.latest_kowloon_checkpoint()
    assert cp['filename']==job['id']+'_completed-kowloon.blend'
    png=next(relay.OUTPUT_DIR.glob('*a25-overview.png'))
    assert png.read_bytes()[:8]==bytes.fromhex('89504e470d0a1a0a')
    ns['reset']();ns['startup_kowloon_restore']()
    assert scene.camera and ns['kowloon_object_count'](scene)==len(steps)
    e=max(e,inspect_meshes())
    report=dict(runtime=bpy.app.version_string,api_max_bytes=relay.MAX_JOB_BYTES,wire_bytes=len(json.dumps(job,ensure_ascii=False).encode()),
        mesh_groups=len(steps),faces=sum(len(s['faces']) for s in steps),maximum_coordinate_error_m=e,
        submit_receive_run_ack=True,duplicate_job_ignored=True,previous_studio_backed_up=True,unrelated_scene_retained=True,
        completed_checkpoint_restored=cp['filename'],render_png_bytes=png.stat().st_size,phone_execution='unobserved')
    (R/f'phase_a/a25_bridge_{tag}.json').write_text(json.dumps(report,indent=2)+'\n')
    http.shutdown();http.server_close()
print('A25_BRIDGE_PASS',report)
