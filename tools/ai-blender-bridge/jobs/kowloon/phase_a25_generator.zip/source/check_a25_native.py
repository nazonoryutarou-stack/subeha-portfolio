"""Compare the saved native scene with the OBJ and its predecessor."""
import bpy,hashlib,json,sys
from pathlib import Path
from array import array
from mathutils import Vector
R=Path(__file__).resolve().parents[1]
def old_state():
    hashes={}
    for ob in bpy.data.objects:
        h=hashlib.sha256(str(tuple(tuple(r) for r in ob.matrix_local)).encode())
        if ob.type=='MESH':
            m=ob.data
            coords=array('f',[0])*len(m.vertices)*3
            loops=array('i',[0])*len(m.loops)
            starts=array('i',[0])*len(m.polygons)
            m.vertices.foreach_get('co',coords);m.loops.foreach_get('vertex_index',loops);m.polygons.foreach_get('loop_start',starts)
            for a in (coords,loops,starts):h.update(a.tobytes())
        hashes[ob.name]=h.hexdigest()
    return hashes,{s.name:sorted(o.name for o in s.objects) for s in bpy.data.scenes}
old=R/'Kowloon_v19_working.blend'
if old.exists():
    bpy.ops.wm.open_mainfile(filepath=str(old));old_objects,old_scenes=old_state()
else:old_objects,old_scenes={},{}
bpy.ops.wm.open_mainfile(filepath=str(R/'Kowloon_v25_working.blend'))
sc=bpy.context.scene;assert sc.name.startswith('A25') and sc.camera and sc.unit_settings.system=='METRIC'
new,scenes=old_state()
assert all(new.get(k)==v for k,v in old_objects.items())
assert all(scenes.get(k)==v for k,v in old_scenes.items())
all_objs={o['part_id']:o for o in sc.objects if o.get('generator')=='phase_a25'}
vs=[];fs=[];part=None;offset=0;mx=0;seen=set();count=0
def check(part,vs,fs):
    if not part:return 0
    obj=all_objs[part];m=obj.data;seen.add(part)
    assert not m.materials and len(m.vertices)==len(vs)
    assert [list(f.vertices) for f in m.polygons]==fs
    assert min(f.area for f in m.polygons)>0
    return max((obj.matrix_world@v.co-Vector(x)).length for v,x in zip(m.vertices,vs))
for line in (R/'model/39_whole_city_registered_exteriors.obj').read_text().splitlines():
    if line.startswith('o '):
        mx=max(mx,check(part,vs,fs));offset+=len(vs);vs=[];fs=[];part=line[2:]
    elif line.startswith('v '):
        x,h,z=map(float,line[2:].split());vs.append([x,-z,h])
    elif line.startswith('f '):
        fs.append([int(x)-1-offset for x in line[2:].split()]);count+=1
mx=max(mx,check(part,vs,fs));assert seen==set(all_objs) and mx<.00002
reg=json.loads((R/'phase_a/a25_register.json').read_text())
assert len(set(p['id'] for p in reg['plots']))==234
assert all('P_'+p['id'] in seen for p in reg['plots'])
assert len({r['id'] for r in reg['observations']})==455
report=dict(version=bpy.app.version_string,opened_saved_blend=True,default_scene=sc.name,previous_object_geometry_and_transforms_checked=len(old_objects),
    previous_scene_memberships_checked=len(old_scenes),obj_faces_verified=count,matching_parts=len(seen),max_obj_native_coordinate_error_m=mx,
    registered_plots=234,source_features_reviewed=455,materials_in_new_geometry=0)
(R/'phase_a/a25_native_checks.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
print('NATIVE_OK',report)
