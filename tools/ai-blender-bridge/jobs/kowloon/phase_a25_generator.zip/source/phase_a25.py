"""Register the expedition's two elevations to the A24 shells in the D04 local frame.

Only the first unobstructed edge can receive a candidate. Preserve the earlier
aperture if it happens to coincide with the new one. All elevations are working
values. No dark feature in the source is classified as a verified window.
"""
from collections import defaultdict, Counter
from pathlib import Path
import json, math
import numpy as np
import shapely
from shapely.geometry import Polygon, box
from shapely.ops import unary_union

ROOT = Path(__file__).resolve().parents[1]
def read(path):
    return json.loads((ROOT/path).read_text())
def write(path, value):
    (ROOT/path).write_text(json.dumps(value, ensure_ascii=False, indent=2)+'\n')
def polygons(shape):
    if shape.is_empty: return []
    if shape.geom_type == 'Polygon': return [shape]
    return [p for h in getattr(shape,'geoms',[]) for p in polygons(h)]
def triangles(shape):
    return shapely.constrained_delaunay_triangles(shape).geoms
class Mesh:
    def __init__(self, name, category, source):
        self.name, self.category, self.source = name, category, source
        self.verts, self.faces, self.indices = [], [], {}
    def face(self, coords):
        ids=[]
        for coord in coords:
            xyz=tuple(round(float(x),5) for x in coord)
            if xyz not in self.indices:
                self.indices[xyz]=len(self.verts)
                self.verts.append(xyz)
            ids.append(self.indices[xyz])
        if len(set(ids))==len(ids) and len(ids)>=3: self.faces.append(ids)
def connected(step):
    vertices=np.array(step['vertices'],float)
    parent=list(range(len(vertices)))
    def root(i):
        while i!=parent[i]:
            parent[i]=i=parent[parent[i]]
        return i
    for face in step['faces']:
        for i in face[1:]: parent[root(i)]=root(face[0])
    parts=defaultdict(list)
    for face in step['faces']: parts[root(face[0])].append(face)
    for faces in parts.values():
        ids=np.unique(np.concatenate(faces))
        yield vertices[ids], [np.searchsorted(ids,f).tolist() for f in faces]
def cross(a,b):
    return a[...,0]*b[...,1]-a[...,1]*b[...,0]
def members(vv, outlines):
    # Use the entire ground ring: adjacent plots often share several corners.
    base=vv[np.abs(vv[:,2])<.001,:2]
    if len(base)<3:return None
    def cost(p):
        ds=np.linalg.norm(base[:,None,:]-p[None,:,:],axis=2)
        return max(ds.min(axis=1).max(),ds.min(axis=0).max())
    errors=[cost(p) for p in outlines]
    i=int(np.argmin(errors))
    return i if errors[i]<.035 else None
def generate():
    city=read('phase_a/city.json')
    obs=read('evidence/full_city/city_observations.json')
    a24=read('automation/a24_input.json')
    orig=a24['source_origin_OBJ']
    offset=np.array([orig[0],-orig[2]])
    rec=city['records']
    outlines=[np.array(r['outline_xz'])*[1,-1]-offset for r in rec]
    cal=city['frame']['calibration']
    north=np.diff(cal['north_arrow_pixels'],axis=0)[0].astype(float)
    north/=np.linalg.norm(north)
    east=np.array([-north[1],north[0]])
    def site(pix):
        q=(np.asarray(pix)-city['frame']['origin_D04_px'])*cal['metres_per_pixel']
        return np.stack([q@east,q@north],axis=-1)-offset

    shells={}
    attachments=[]
    for part_no in range(42,50):
        for vv,ff in connected(a24['steps'][part_no]):
            i=members(vv,outlines)
            if i is not None:
                assert i not in shells, rec[i]['id']
                shells[i]=(vv,ff)
            else:
                attachments.append((vv,ff,part_no))
    assert len(shells)==len(rec)==234,len(shells)
    edges=[]
    for i,ring in enumerate(outlines):
        for j,(a,b) in enumerate(zip(ring,np.roll(ring,-1,axis=0))):
            length=float(np.linalg.norm(b-a))
            if length>.1:edges.append((i,j,a,b,length))
    starts=np.array([e[2] for e in edges]); vectors=np.array([e[3]-e[2] for e in edges])
    heights={i:float(vv[:,2].max()) for i,(vv,ff) in shells.items()}
    samples=defaultdict(list); pending=defaultdict(list); ledger=[]
    for side in ['south','west']:
        data=read(f'evidence/full_city/{side}_elevation_observations.json')
        path=site(obs[side+'_perimeter'])
        dist=np.r_[0,np.cumsum(np.linalg.norm(np.diff(path,axis=0),axis=1))]
        left,right=data['span']; ground=np.array(data['ground_profile']); vert=data['working_vertical_metres_per_pixel']
        def probe(u):
            distance=dist[-1]*(u-left)/(right-left)
            k=int(np.clip(np.searchsorted(dist,distance,side='right')-1,0,len(path)-2))
            tangent=(path[k+1]-path[k])/(dist[k+1]-dist[k]); inward=np.array([-tangent[1],tangent[0]])
            p=path[k]+tangent*(distance-dist[k])
            den=cross(np.broadcast_to(inward,vectors.shape),vectors)
            with np.errstate(divide='ignore',invalid='ignore'):
                depth=cross(starts-p,vectors)/den
                t=cross(starts-p,inward)/den
            valid=(depth>=-5)&(depth<=10)&(t>=0)&(t<=1)
            if not np.any(valid): return None
            n=int(np.argmin(np.where(valid,depth,np.inf)))
            if abs(den[n])/edges[n][4]<.45:return None
            return (n,float(t[n])*edges[n][4],float(depth[n]))
        def z(u,v):return float((np.interp(u,ground[:,0],ground[:,1])-v)*vert)
        for u,v in data['roof_profile']:
            hit=probe(u)
            if hit:samples[edges[hit[0]][0]].append((side,u,z(u,v)))
        for hole in data['opening_candidates']:
            x0,y0,x1,y1=hole['rect'];u=(x0+x1)/2
            result=dict(id=hole['id'],view=side,pixels=hole['rect'],status='unassigned_or_crosses_edge')
            ledger.append(result)
            hits=[probe(x) for x in (x0,u,x1)]
            if None in hits or len({h[0] for h in hits})!=1:continue
            n=hits[1][0];i,j,a,b,length=edges[n]
            lo,hi=sorted([hits[0][1],hits[-1][1]])
            low,high=z(u,y1),z(u,y0)
            if min(lo,length-hi,low)<.035 or hi-lo<.12 or high-low<.12:continue
            result.update(parcel=rec[i]['id'],edge=j,hit_depth_m=round(hits[1][2],3),status='above_working_roof_or_no_wall')
            pending[(i,j)].append((box(lo,low,hi,high),result))
    revised={}
    for i,values in samples.items():
        if len(values)>=4 and rec[i]['storeys'] is None:
            revised[i]=round(float(np.median([x[2] for x in values])),2)
    roof_tests=read('phase_a/roof_parcel_candidates.json')
    patches={p['id']:p for p in city['roof_patches']}
    roof_candidates=defaultdict(list)
    for test in roof_tests:
        if (test['same_candidate_all_fits'] and test['minimum_winning_fraction']>=.50
                and test['base_overlap_fraction']>=.65 and test['base_candidate']):
            roof_candidates[test['base_candidate']].append(patches[test['roof']])
    parts=[];register=[]
    for i,(vv,ff) in sorted(shells.items()):
        old=heights[i]; top=revised.get(i,old); vv=vv.copy();vv[:,2]*=top/old
        shape=Mesh('P_'+rec[i]['id'],'plot',rec[i]['source'])
        shape.plot=rec[i]['id']
        consumed=set()
        ring=outlines[i]
        sign=1 if cross(ring,np.roll(ring,-1,axis=0)).sum()>0 else -1
        for j,(a,b) in enumerate(zip(ring,np.roll(ring,-1,axis=0))):
            if not pending[(i,j)]:continue
            tangent=(b-a)/np.linalg.norm(b-a)
            ids=[]; projected=[]
            for k,face in enumerate(ff):
                if k in consumed:continue
                v=vv[face]; delta=v[:,:2]-a
                if np.abs(cross(delta,tangent)).max()>.018 or np.ptp(v[:,2])<.03:continue
                along=delta@tangent
                if along.min()<-.02 or along.max()>np.linalg.norm(b-a)+.02:continue
                p=Polygon(np.column_stack([along,v[:,2]])).buffer(0)
                if p.area>.001:ids.append(k);projected.append(p)
            if not ids:continue
            base=unary_union(projected)
            cuts=[]
            for rect,row in pending[(i,j)]:
                if rect.bounds[3]>=top-.06:continue
                if base.intersection(rect).area/rect.area<.97:
                    row['status']='overlap_with_existing_void_or_edge';continue
                if any(rect.intersects(prev) for prev in cuts):
                    row['status']='overlap_with_another_candidate';continue
                cuts.append(rect);row['status']='cut_candidate';row['area_m2']=round(rect.area,4)
            if not cuts:continue
            consumed.update(ids)
            def vpoint(s,z):return [*(a+tangent*s),z]
            # The 0.20m return is a switchable working depth inherited from
            # the earlier elevation studies. Leave the back of each void open.
            inward=np.array([-tangent[1],tangent[0]])*sign*.20
            from shapely.geometry import Point
            footprint=Polygon(ring).buffer(.015)
            for rect,row in pending[(i,j)]:
                if row['status']!='cut_candidate':continue
                corners=[vpoint(s,z) for s,z in list(rect.exterior.coords)[:4]]
                inner=[[x+inward[0],y+inward[1],z] for x,y,z in corners]
                if all(footprint.covers(Point(x,y)) for x,y,z in inner):
                    row['return_depth_m_provisional']=.20
                    for k in range(4):
                        n=(k+1)%4
                        shape.face([corners[k],corners[n],inner[n],inner[k]])
            for poly in polygons(base.difference(unary_union(cuts))):
                for tri in triangles(poly):
                    pts=list(tri.exterior.coords)[:3]
                    if (cross(np.subtract(pts[1],pts[0]),np.subtract(pts[2],pts[0]))>0)!=(sign>0):pts.reverse()
                    shape.face([vpoint(*p) for p in pts])
        # Partition the existing plane; no new rise, slope, or parapet is inferred.
        roof_ids=[k for k,f in enumerate(ff) if np.max(np.abs(vv[f,2]-top))<.012]
        roof_records=[]
        if roof_ids and roof_candidates[shape.plot]:
            roof=unary_union([Polygon(vv[ff[k],:2]).buffer(0) for k in roof_ids])
            remaining=roof
            def roof_faces(mesh, region):
                for piece in polygons(region):
                    for tri in triangles(piece):
                        points=list(tri.exterior.coords)[:3]
                        if cross(np.subtract(points[1],points[0]),np.subtract(points[2],points[0]))<0:points.reverse()
                        mesh.face([[x,y,top] for x,y in points])
            for patch in roof_candidates[shape.plot]:
                traced=Polygon(np.array(patch['outline_xz'])*[1,-1]-offset).buffer(0)
                split=remaining.intersection(traced)
                if split.area<1:continue
                marked=Mesh('Roof_'+patch['id']+'_'+shape.plot,'aerial roof division',patch['source'])
                roof_faces(marked,split);parts.append(marked)
                roof_records.append(dict(trace=patch['id'],area_on_working_plane_m2=round(split.area,4),
                    date=patch['date'],assignment='hypothesis; silhouette overlap across registration alternatives'))
                remaining=remaining.difference(traced)
            if roof_records:
                consumed.update(roof_ids);roof_faces(shape,remaining)
                assert abs(roof.area-remaining.area-sum(r['area_on_working_plane_m2'] for r in roof_records))<.02
        for k,f in enumerate(ff):
            if k not in consumed:shape.face(vv[f])
        parts.append(shape)
        register.append(dict(id=shape.plot,source=rec[i]['source'],storeys=rec[i]['storeys'],height_A24=old,height_A25=top,
            height_status='elevation_first_hit_median_hypothesis' if i in revised else ('known_storeys_assumed_pitch' if rec[i]['storeys'] else 'A24_neighbour_interpolation'),
            roof_subdivisions=roof_records,elevation_samples=samples[i],date=rec[i]['date'],target_epoch=rec[i]['target_epoch']))
    # Attachments disconnected in the deployed mesh retain their own ownership.
    # D04 plots keep the same nominal height. Inferred slabs attach to their own
    # sill by shared mesh topology and were already transformed with the shell.
    for n,(vv,ff,part_no) in enumerate(attachments):
        mesh=Mesh(f'Attachment_{n:03}','A24 projection','A24 provisional cantilever or parapet')
        for f in ff:mesh.face(vv[f])
        parts.append(mesh)
    for j in range(2,42):
        s=a24['steps'][j];mesh=Mesh(f'A24_{j:02}', 'street' if j>=37 else ('west study' if j>=33 else 'north survey'),s['name'])
        for f in s['faces']:
            xyz=np.array([s['vertices'][k] for k in f])
            # Early bridge jobs placed a solid copy of each north wall behind
            # its later perforated shell. Keep sections/passages and remove only
            # exact ground-to-roof duplicates of registered wall segments.
            if j<30 and xyz[:,2].min()==0 and np.ptp(xyz[:,2])>15:
                xy=np.unique(xyz[:,:2],axis=0)
                if len(xy)==2:
                    same=((np.linalg.norm(starts-xy[0],axis=1)<.02)&(np.linalg.norm(starts+vectors-xy[1],axis=1)<.02))|((np.linalg.norm(starts-xy[1],axis=1)<.02)&(np.linalg.norm(starts+vectors-xy[0],axis=1)<.02))
                    if any(rec[edges[e][0]]['storeys'] and abs(rec[edges[e][0]]['storeys']*2.65-xyz[:,2].max())<.02 for e in np.flatnonzero(same)):continue
            mesh.face(xyz)
        if mesh.faces:parts.append(mesh)
    # D04's nine separate central roof-plan bands occupy the mapped central void.
    # Their earlier extrusion mixed a sloped terrain with the level A24 datum.
    # Use the same zero comparison datum as the surrounding district.
    for n,band in enumerate(obs['lowrise_central']['bands']):
        ring=site(band)
        footprint=Polygon(ring)
        assert max(footprint.intersection(Polygon(p).buffer(0)).area for p in outlines)/footprint.area < .005
        mesh=Mesh(f'Central_band_{n:02}','central low rise','D04 City Fig 2; nine visible plan bands; assumed height 3.2 m, roof section unknown')
        for tri in triangles(footprint):
            mesh.face([[x,y,3.2] for x,y in list(tri.exterior.coords)[:3]])
        for a,b in zip(ring,np.roll(ring,-1,axis=0)):
            mesh.face([[*a,0],[*b,0],[*b,3.2],[*a,3.2]])
        parts.append(mesh)
    return parts,register,ledger,offset
def export(parts,offset):
    count=0
    with (ROOT/'model/39_whole_city_registered_exteriors.obj').open('w') as f:
        f.write('# A25 | 1993 survey plan with provisional building envelopes. X east Y up Z south. Metres. See phase_a/a25_register.json\n')
        for mesh in parts:
            f.write('o '+mesh.name+'\n')
            for x,y,z in mesh.verts:f.write(f'v {x+offset[0]:.5f} {z:.5f} {-y-offset[1]:.5f}\n')
            for face in mesh.faces:f.write('f '+' '.join(str(i+1+count) for i in face)+'\n')
            count+=len(mesh.verts)
if __name__=='__main__':
    parts,register,ledger,offset=generate()
    export(parts,offset)
    write('phase_a/a25_register.json',dict(plots=register,observations=ledger,parts=[dict(name=m.name,category=m.category,source=m.source) for m in parts]))
    cuts=[r for r in ledger if r['status']=='cut_candidate']
    print('Shells, new skyline fits, candidate cuts:',len(register),sum(r['height_status'].startswith('elevation') for r in register),Counter(r['view'] for r in cuts))
    print('Edits on distinct plots',len(set(r['parcel'] for r in cuts)),'Observation status',Counter(r['status'] for r in ledger))
    print('Parts',Counter(m.category for m in parts),'Verts',sum(len(m.verts) for m in parts))
